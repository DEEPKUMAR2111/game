import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs';
import { throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class PostService {

  url='http://localhost:3000/posts';
  
  constructor( private http:HttpClient) {  }

getPost(){
  return this.http.get(this.url).pipe(catchError(this.errorHandel));
  
}

errorHandel(error:HttpErrorResponse){  
  return throwError(error.message || 'server Error');
}

 createPost(post: any){
 return this.http.post(this.url,post).pipe(catchError(this.errorHandel));
 }

 updatePost(post:any){
 return this.http.patch(this.url+'/'+post.id,post)
 }

 deletePost(post:any){
 
  return this.http.delete(this.url+'/'+post.id,post).pipe(catchError(this.errorHandel));
 }

 update(post:any,newData: any){

  return this.http.put(this.url+'/'+post.id,newData).pipe(catchError(this.errorHandel));
 }

}