import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

constructor(private router:Router,private toastr: ToastrService){}

data: any;
showData=false;
errors=false;


submitted=false;
 login= new FormGroup({ 
    email : new FormControl('',[Validators.required,Validators.email]),
    password :new FormControl('',[Validators.required,Validators.minLength(4)]),
  });
  get email(){
    return this.login.get('email');
  }
  get password(){
    return this.login.get('password');
  }


  goTo(){
    this.router.navigate(['user/signup'])
  }

  submit(data:any){

    console.warn(this.login.value);
    this.submitted= true;
    this.data=data;
    console.log(this.data);
   
    if(data.password!=='1234' || data.email!=="deep@12.com" || this.login.invalid){

        this.errors=true;
        this.toastr.error('Invalid Email or Password');
        
      }
      else{
        this.toastr.success('Login Successfully...!');
    this.router.navigate(['/user/data'])

      }
  }

}
