import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { BrowserModule } from '@angular/platform-browser';
import { UserlistComponent } from './userlist/userlist.component';
import { UserdataComponent } from './userdata/userdata.component';



@NgModule({
  declarations: [
    LoginComponent,
    SignupComponent,
    UserlistComponent,
    UserdataComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports:[
    LoginComponent,
    SignupComponent
  ]
})
export class UserModule { }
