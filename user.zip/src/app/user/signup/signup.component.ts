import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  errors: boolean=false;
  constructor(private router:Router,private toastr: ToastrService){}
  signup= new FormGroup({ 
    Username : new FormControl('',[Validators.required]),
    email : new FormControl('',[Validators.required,Validators.email]),
    password :new FormControl('',[Validators.required,Validators.minLength(4)]),
    terms :new FormControl('',[Validators.required]),
  });

  get Username(){
    return this.signup.get('Username');
  }
  get email(){
    return this.signup.get('email');
  }
  get password(){
    return this.signup.get('password');
  }
  get terms(){
    return this.signup.get('terms');
  }

  submit(data:any){
    console.warn(data);
    if(this.signup.invalid){

      this.errors=true;
      this.toastr.error('Invalid Details');
    }
    else{
    this.toastr.success('Registration Successfully...!');
    this.router.navigate(['user/data'])
    }
  }

  goTo(){
    this.router.navigate(['user/login'])
  }
}
