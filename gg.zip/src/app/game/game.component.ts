import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css']
})



export class GameComponent {

  board = [ 
  [{value: ''}, {value: ''}, {value: ''}, {value: ''}],
  [{value: ''}, {value: ''}, {value: ''}, {value: ''}],
  [{value: ''}, {value: ''}, {value: ''}, {value: ''}],
  [{value: ''}, {value: ''}, {value: ''}, {value: ''}]
];
  player = 'X';
  winner = '';
  win=false;
  Draw=false;
  count=0;


  start(cell: any) {
    if (cell.value || this.winner) {
      return;
    }
    cell.value = this.player;
    this.checkForWin();
    this.draw();




    
    this.player = this.player === 'X' ? 'O' : 'X';
  }

  checkForWin() {
    const winning= [      
      [[0, 0], [0, 1], [0, 2], [0, 3]],
      [[1, 0], [1, 1], [1, 2], [1, 3]],
      [[2, 0], [2, 1], [2, 2], [2, 3]],
      [[3, 0], [3, 1], [3, 2], [3, 3]],
      [[0, 0], [1, 0], [2, 0], [3, 0]],
      [[0, 1], [1, 1], [2, 1], [3, 1]],
      [[0, 2], [1, 2], [2, 2], [3, 2]],
      [[0, 3], [1, 3], [2, 3], [3, 3]],
      [[0, 0], [1, 1], [2, 2], [3, 3]],
      [[0, 3], [1, 2], [2, 1], [3, 0]]
    ];

    for (let situation of winning) {
      let [a, b, c, d] = situation;
      let [rowA, boxA] = a;
      let [rowB, boxB] = b;
      let [rowC, boxC] = c;
      let [rowD, boxD] = d;



      if (
        this.board[rowA][boxA].value === this.player &&
        this.board[rowB][boxB].value === this.player &&
        this.board[rowC][boxC] .value=== this.player &&
        this.board[rowD][boxD].value === this.player
      ) {
        this.winner = this.player;
        this.win=true
        

        return;
      }
    }
  }

  reset(){
    this.player='X';
    this.win=false;
    this.winner="";
    this.Draw=false;
    this.board= [ 
      [{value: ''}, {value: ''}, {value: ''}, {value: ''}],
      [{value: ''}, {value: ''}, {value: ''}, {value: ''}],
      [{value: ''}, {value: ''}, {value: ''}, {value: ''}],
      [{value: ''}, {value: ''}, {value: ''}, {value: ''}]
    ];
  }

  draw(){
    this.count=0;
    for (let i = 0; i < this.board.length; i++) {
      for (let j = 0; j < this.board.length; j++) {
        if (this.board[i][j].value != '') {
          this.count++
        }
       
      }
    }
    if(this.count==16){
      this.Draw=true;
    }
  }
  }



    // let board=this.board;
    // let rows=board.length;
    // let boxes=board[0].length;

    // for(let row=0;row<rows;row++){
    //   for(let box=0;box<boxes;box++){
    //       if(board[row][box]===''){
    //         continue;
    //       }
    //     if(box + 3< boxes && board){

    //     }
    //   }
    // }


 //   let lines=[
  //     [0,1,2,3],
  //     [4,5,6,7],
  //     [8,9,10,11],
  //     [12,13,14,15],
  //     [0,4,8,12],
  //     [1,5,9,13],
  //     [2,6,10,14],
  //     [3,7,11,15],
  //     [0,5,10,15],
  //     [3,6,9,12]
  //   ];
  

 