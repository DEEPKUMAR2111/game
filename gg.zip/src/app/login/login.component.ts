import { Router } from '@angular/router';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  showData=false;
  errors=false;
  
  constructor(private router:Router){

  }
  show={email:'deep@12.com',password:'1234'}
  data: any;

  submitted=false;
   login= new FormGroup({ 
      email : new FormControl('',[Validators.required,Validators.email]),
      password :new FormControl('',[Validators.required,Validators.minLength(4)]),
    });
    get email(){
      return this.login.get('email');
    }
    get password(){
      return this.login.get('password');
    }
  
  submit(data:any){
    console.warn(this.login.value);
    this.submitted= true;
    this.data=data;
    console.log(this.data);
   
    if(data.password!=='1234' || data.email!=="deep@12.com"){

        this.errors=true;
      alert("Email And Password Not Match With Users, Click on Show Button to Know Login Details") ;
      }
      else{
        if(this.login.valid==true){
        this.router.navigate(["/game"])
      }
      }
  }

  showIn(){
    this.showData= !this.showData;
  }
 

}



