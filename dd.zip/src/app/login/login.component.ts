import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl, ValidationErrors, FormArray } from '@angular/forms';


@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

submitted=false;
  login= new FormGroup({
    userName : new FormControl('',[Validators.required,Validators.minLength(3)]),
    email : new FormControl('',[Validators.required,Validators.email]),
    password :new FormControl('',[Validators.required,Validators.minLength(4)]),
    rpassword: new FormControl('',[Validators.required ,Validators.minLength(4)]),
    age: new FormControl('',[Validators.required,Validators.pattern('[0-9]+$'),Validators.min(18)]),
    hobbies: new FormArray([],[Validators.required]),
    gender:new FormControl('',[Validators.required]),
    country: new FormControl('',[Validators.required])
    
  },{ validators: [MatchValidator.validate]}); 
  
  
  data:any;
  valid: boolean = true;
  hobbies:string[]=['Cricket','Coding','Chess']


  submit(data:any){
    console.warn(this.login.value);
    this.submitted= true;
    this.data=data;
    console.log(this.data);
    let userData:any=localStorage.getItem('userData') || '[]'
    userData=JSON.parse(userData);
    if(!this.login.valid){
      return ;
      }
      else{
    userData.push(this.data)
    localStorage.setItem("userData", JSON.stringify(userData));
      }
  }


  get userName(){
    return this.login.get('userName');
  }
  get email(){
    return this.login.get('email');
  }
  get password(){
    return this.login.get('password');
  }
  get rpassword(){
    return this.login.get('rpassword');
  }
  get age(){
    return this.login.get('age');
  }
  
  get gender(){
    return this.login.get('gender');
  }
  get country(){
    return this.login.get('country');
  }

  onChange(h:any){
    var checked=h.target.value;
    var bchecked=h.target.checked;
   console.log(checked);
   var checkedArray=this.login.get('hobbies')as FormArray;

   if(bchecked){
    checkedArray.push(new FormControl(checked));
   }
   else{
    var i=0;
    checkedArray.controls.forEach((item) => {
     if(item.value==checked){
      checkedArray.removeAt(i);
     }
     i++;
    });
   }
  }

}


export class MatchValidator {
  static validate(group: AbstractControl): ValidationErrors | null { 
    const password = group.get('password')?.value;
    const rpassword = group.get('rpassword')?.value;

    return password === rpassword ? null : { notMatching: true }
  };
}


