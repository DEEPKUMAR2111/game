import { NgForm } from '@angular/forms';
import { PostService } from './../services/post.service';
import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit{
  posts: any;
  fData:any;
  activeError=false;
  err="";

  @ViewChild('form')
  form!: NgForm;
  currentId:any;
  constructor(private service:PostService) { 
     
    }
  ngOnInit() {
    this.service.getPost().toPromise().then(data =>{ this.posts = data},error=>{
      this.activeError=true;
       this.err="Unexpected Error :404 Not Found";
      console.log('404 Not Found');
    });
  }
  
    createPost(post: any){
     
      this.service.createPost(post).toPromise().then(data=>{
          post=data;
          this.posts.splice(this.posts.length,0,post);
          console.log(data);    
        },
        (error:Response)=>{
          // this.activeError=true;
           var errorName="Can't Add This Item.";
           alert(errorName);
          console.log('404 Not Found');
        }
        
        );

      
    }

    updatePost(post:any){
      this.service.updatePost(post)
      .toPromise().then(data=>{
        // console.log(data);
        let index=this.posts.indexOf(post);
      this.currentId=data;
      this.form.setValue(this.currentId)
      console.log(data);
      data="";
    })
    }

    deletePost(post:any){
      this.service.deletePost(post).toPromise().then(data=>{
        let index=this.posts.indexOf(post);
        console.log(index);
        this.posts.splice(index,1);
        console.log(data);
    },
    (error:Response)=>{
      // this.activeError=true;
       var errorName="Can't Delete This Item.";
       alert(errorName);
      console.log('404 Not Found');
    }
    ) ;
    }

    update(post:any){
      this.service.update(this.currentId,post).toPromise().then(data=>{ 
        let index=this.posts.indexOf(post);
        this.posts.splice(index,1,post);
        console.log(data);},
        (error:Response)=>{
          // this.activeError=true;
           var errorName="Can't Update This Item.";
           alert(errorName);
          console.log('404 Not Found');
        }
        );
        
    }


}
