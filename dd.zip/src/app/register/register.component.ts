import { Component } from '@angular/core';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
 

//   submitted: boolean = false;
  
//   submit(y: any,z:any){
//     var data = [];
//     this.submitted=true;
//    if(z==true){
//     data.push(y);
//     localStorage.setItem("data", JSON.stringify(data));
//   console.log(data);
//    }
// }


}
